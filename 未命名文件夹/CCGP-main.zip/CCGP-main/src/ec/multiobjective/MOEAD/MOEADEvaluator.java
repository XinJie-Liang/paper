package ec.multiobjective.MOEAD;

import ec.simple.SimpleEvaluator;

public class MOEADEvaluator extends SimpleEvaluator{

}
