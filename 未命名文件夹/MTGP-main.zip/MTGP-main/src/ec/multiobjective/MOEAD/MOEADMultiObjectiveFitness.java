package ec.multiobjective.MOEAD;

import ec.multiobjective.MultiObjectiveFitness;

public class MOEADMultiObjectiveFitness extends MultiObjectiveFitness{

	
}
